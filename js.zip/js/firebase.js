const firebaseConfig = {
  apiKey: "AIzaSyAkZO9_PxSDKS2gxIVxXgYwEyiERSaDS7Q",
  authDomain: "college-explorer-portal.firebaseapp.com",
  projectId: "college-explorer-portal",
  storageBucket: "college-explorer-portal.appspot.com",
  messagingSenderId: "748456291775",
  appId: "1:748456291775:web:1aaa015a4d2e56ee59450a",
  measurementId: "G-PQE04LZY8F"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);